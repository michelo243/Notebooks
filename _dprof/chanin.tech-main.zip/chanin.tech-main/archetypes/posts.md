---
title: "{{ replace .Name "-" " " | title }}"
date: {{ .Date }}
slug:
category:
summary:
description: Same as the summary
cover:
  image:
  alt:
  caption:
  relative: false
showtoc: true
draft: true
---