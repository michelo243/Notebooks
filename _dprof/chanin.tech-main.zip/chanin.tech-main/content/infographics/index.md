---
title: "Infographics"
date: 2022-04-09T23:15:00+07:00
slug: infographics
category:
summary:
description:
cover:
  image:
  alt:
  caption:
  relative: true
showtoc: false
draft: false
---

I also create hand-drawn infographics and illustrations to summarize the key concepts in data science, machine learning and bioinformatics.
