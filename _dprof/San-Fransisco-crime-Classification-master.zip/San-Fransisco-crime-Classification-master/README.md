# San-Fransisco-crime-Classification
I make a classifier model with sklearn with accoracy 84% and deploy it with streamlit.



[![Streamlit App](https://static.streamlit.io/badges/streamlit_badge_black_white.svg)](https://muhammadammar26627-san-fransisco-c-appstreamlit-tetorial-w8mqz3.streamlitapp.com/)
