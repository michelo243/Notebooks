Scripts to create experimental result graphs found in source code:

district_comparisons: Comp_Districts_City.py
parameter_comparisons: Whole_city.py
model_selection_bar: Bayview XGB.py

F1 Scores for each district found in subfolder: export_f1_scores_per_district that generated from scripts in source code(note: they send to same folder
as executed in).