# san-fransisco-crimes-prediction
hey humans!
This model mainly focusses on data visualisation and geospatial analysis of San Francisco crimes dataset
